module.exports = {
    //Worksheet
    UPLOAD: {
        UPLOAD_IMAGE: "UPLOAD_IMAGE",
        DELETE_IMAGE: "DELETE_IMAGE",
    },

};