// Response constants

module.exports = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR'
};