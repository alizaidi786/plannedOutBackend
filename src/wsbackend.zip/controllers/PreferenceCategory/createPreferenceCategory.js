const responseConstant = require("../../constants/response.constants")
const db = require("../../helpers/db/index")
const response = require("../../helpers/response.maker")

module.exports.create = async (data) => {
    var Connection = await db.connectToDatabase()

    var CategoryModel = Connection.model('preference_categories')

    var {
        name,
        description
    } = data
    let categoryData = {
        name,
        description
    }
    var ins = new CategoryModel(categoryData)
    return await ins.save().then(async () => {
        return await response.success(responseConstant.PREFERENCE_CATEGORY.CREATE_PREFERENCE_CATEGORY_SUCCESS, categoryData)
    }).catch(async (e) => {
        return await response.error(responseConstant.PREFERENCE_CATEGORY.CREATE_PREFERENCE_CATEGORY_ERROR, { message: e })
    })
}